import os
from discord.ext import commands
import re
import pickle
import logging
import asyncio
from dotenv import load_dotenv
import glob
from discord.ext import tasks
from time import sleep
import threading
from datetime import datetime
from datetime import timedelta
import pytz
import discord
from discord.utils import get

poll_emojis = {1: ':one:', 2: ':two:', 4: ':thumbsup:', 5: ':thumbsdown:'}
ctxAnnounce = ''
ctxInteract = ''
load_dotenv()

TOKEN = os.getenv('DISCORD_TOKEN')
client = discord.Client()
bot = commands.Bot(command_prefix='$')
channel_id = 838414377613787136

class classroom():
    def __init__(self, name, block=None):
        self.name = name
        self.block = block
        self.assignments = []

    def homework_create(self, thisAssignment):
        self.assignments.append(thisAssignment)

    def addToVerify(self, thisAssignment, message):
        for i in range(999999999):
            if i not in self.toBeVerified.keys():
                self.toBeVerified[i] = thisAssignment
                self.toBeVerifiedMessages[i] = message
class assignment():
    def __init__(self, name=None, date=None, urgent=None, summative=False, isTest=False):
        self.name = name
        self.date = date
        self.urgency = urgent
        self.summative = summative
        self.isTest = isTest
        self.sentNotifDue = False
        self.sentNotifDueToday = False

files = glob.glob('*.pickle')
if 'English.pickle' not in files:
    English = classroom('English')
else:
    English = pickle.load(open(f'English.pickle', 'rb'))

if 'Math Extended.pickle' not in files:
    MathExtended = classroom('Math Extended')
else:
    MathExtended = pickle.load(open(f'Math Extended.pickle', 'rb'))

if 'Ethics.pickle' not in files:
    Ethics = classroom('Ethics and Virtues')
else:
    Ethics = pickle.load(open(f'Ethics.pickle', 'rb'))

if 'Business.pickle' not in files:
    Business = classroom('Business')
else:
    Business = pickle.load(open(f'Business.pickle', 'rb'))

if 'History.pickle' not in files:
    History = classroom('History')
else:
    History = pickle.load(open(f'History.pickle', 'rb'))

if 'Ceramics.pickle' not in files:
    Ceramics = classroom('Ceramics')
else:
    Ceramics = pickle.load(open(f'Ceramics.pickle', 'rb'))

if 'Economics.pickle' not in files:
    Economics = classroom('Economics')
else:
    Economics = pickle.load(open(f'Economics.pickle', 'rb'))

if 'Japanese.pickle' not in files:
    Japanese = classroom('Japanese')
else:
    Japanese = pickle.load(open(f'Japanese.pickle', 'rb'))

if 'Physics.pickle' not in files:
    Physics = classroom('Physics')
else:
    Physics = pickle.load(open(f'Physics.pickle', 'rb'))

classes = [English, MathExtended, Ethics, Business, History, Ceramics, Economics, Japanese, Physics]

for clas in classes:
    with open(clas.name + '.pickle', 'wb') as output:
        pickle.dump(clas, output, pickle.HIGHEST_PROTOCOL)

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')


@bot.command()
async def assign(ctx, *args):
    global ctxAnnounce
    ctxInteract = ctx

    if ctx.channel.id == 838414377613787136:
#    try:
        fullText = ''
        for arg in args:
            fullText = fullText + " " + arg

        if 'english' in fullText.lower():
            date = args[1]

            name = ''
            for arg in range(2, len(args)):
                name = name + ' ' + args[arg]

        if 'math extended' in fullText.lower():
            date = args[2]
            name = ''
            for arg in range(3, len(args)):
                name = name + ' ' + args[arg]


        thisAssignment = assignment()


        for clas in classes:
            if clas.name.lower() in fullText.lower():
                classroom = clas
                spaces = clas.name.count(' ')
                date = args[spaces+1]
                name = ''
                for arg in range(spaces+2, len(args)):
                    name = name + ' ' + args[arg]

        if re.match(r'^\d{2}/\d{2}/\d{4}$', date) is not None:
            date = re.match(r'^\d{2}/\d{2}/\d{4}$', date).string
            thisAssignment.date = date
        else:
            await ctx.send('improper date')
            return None

        thisAssignment.name = name

        if thisAssignment.isTest == True:
            posted_message = await ctx.send('Is the assignment:' + thisAssignment.name + ' real? react with :thumbsup: to verify \n(6 required)')
            await posted_message.add_reaction('\U0001F44D')
            await posted_message.pin()
            assignmentReq = 6
        else:
            posted_message = await ctx.send('Is the assignment:' + thisAssignment.name + ' real? react with :thumbsup: to verify \n(4 required)')
            await posted_message.add_reaction('\U0001F44D')
            await posted_message.pin()
            assignmentReq = 4

        try:
                async def reactionFunction():
                    while True:
                        reaction, user = \
                            await bot.wait_for('reaction_add', check = lambda reaction,
                                                                                 user: str(reaction.emoji) == '👍', timeout=21600.0)  # Wait 1 minute for any reaction
                        if reaction.message.id == posted_message.id:  # If the message reacted to is the one we sent (msg)
                            for reaction in reaction.message.reactions:
                                if reaction.count >= assignmentReq:  # If the reactions of that message are the number we game (votes_to_pass) or more then
                                    classroom.homework_create(thisAssignment)
                                    new = await ctxInteract.send(
                                        '@' + classroom.name + '  Assignment' + thisAssignment.name + ' created in ' + classroom.name + '.\nDue: ' +
                                        thisAssignment.date)
                                    await posted_message.delete()
                                    await new.pin()
                                    for clas in classes:
                                        with open(clas.name + '.pickle', 'wb') as output:
                                            pickle.dump(clas, output, pickle.HIGHEST_PROTOCOL)
                                    return  # This returns out of the function.
                await reactionFunction()
        except:
                await ctx.send("Unverified post, deleting")
                await posted_message.delete()



#    except:
#        await ctx.send('Improper Syntax')

@bot.command()
async def assignments(ctx):
        global classes
        total = ''
        for clas in classes:
            if clas.assignments != [] and not clas.name in total:
                ass = clas.name + ': '
                for assignmen in clas.assignments:
                    ass = ass + assignmen.name + ': Due ' + assignmen.date + ', '
                total = total + ass + '\n'
        try:
            await ctx.send(total)
        except:
            await ctx.send('No assignments entered')

@bot.command()
async def init(ctx, arg):
        if arg == 'announce':
            print('done')
            ctxAnnounce = ctx
        elif arg == 'interact':
            print('done')
            ctxInteract = ctx


@tasks.loop(seconds=10)
async def checkTime():
    if ctxAnnounce != '':
        tz_Tokyo = pytz.timezone('Japan')
        datetime_Tokyo = (datetime.now(tz_Tokyo)) - timedelta(days=1)
        for clas in classes:
            for task in clas.assignments:
                if task.date == str(datetime_Tokyo.strftime('%m/%d/%Y')):
                    await ctxInteract.send('Removed ' + task.name + '\n(Due Date passed)')
                    clas.assignments.remove(task)

        datetime_Tokyo = (datetime.now(tz_Tokyo)) + timedelta(days=1)
        datetime_Tokyo_Today = datetime.now(tz_Tokyo)
        for clas in classes:
            for task in clas.assignments:
                if task.date == str(datetime_Tokyo.strftime('%m/%d/%Y')):
                    if not task.sentNotifDue:
                        task.sentNotifDue = True
                        await ctxAnnounce.send('@' + clas.name +'  Assignment: ' + task.name + ' due tomorrow for class: ' + clas.name)
                elif task.date == str(datetime_Tokyo_Today.strftime('%m/%d/%Y')):
                    if not task.sentNotifDueToday:
                        task.sentNotifDueToday = True
                        await ctxAnnounce.send('@' + clas.name +'  Assignment: ' + task.name + ' due TODAY for class: ' + clas.name)


checkTime.start()
bot.run(TOKEN)
